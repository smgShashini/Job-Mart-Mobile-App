//_______________________________________________________________________________________
// Class Description : Let users to create account
//                     Upload image
//                     Input text
// Actions           : Save entered data into firestore
// Linked Screens    :
//_______________________________________________________________________________________

import 'package:flutter/material.dart';
import 'package:jobmart/screens/homeDshboardPage.dart';
import 'package:jobmart/screens/homePage.dart';
import 'package:jobmart/screens/inputWithIcon.dart';


class CreateAccount extends StatefulWidget {
  @override
  _CreateAccountState createState() => _CreateAccountState();
}

class _CreateAccountState extends State<CreateAccount> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //color: Colors.white,

      body: Column(
        children: [
          SizedBox(
            height: 50,
          ),

          //------------ [Begin] Upload image section ---------
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 75,
                backgroundColor: Color(0xFFB4A3B3B),
              ),
              Container(
                margin: EdgeInsets.only(top: 90),
                  child: Icon(Icons.camera_alt,color: Color(0xFFB4A3B3B),)),
            ],
          ),
          //------------ [End] Upload image section ---------


          //------------ [Begin] Text field section ---------
          Inputwithicon(
            textFieldHint: 'Enter your name',
            textFiledName: 'Name',
            textIcon:Icon( Icons.account_box),
          ),
          Inputwithicon(
            textFieldHint: 'Enter your job',
            textFiledName: 'Job tittle',
            textIcon:Icon( Icons.work),
          ),
          Inputwithicon(
            textFieldHint: 'Enter your working area',
            textFiledName: 'Working Area',
            textIcon:Icon( Icons.location_on),
          ),
          Inputwithicon(
            textFieldHint: 'Enter your Contact number',
            textFiledName: 'Contact Number',
            textIcon:Icon( Icons.phone),
          ),
          Inputwithicon(
            textFieldHint: 'Enter your birth day',
            textFiledName: 'Birth day',
            textIcon:Icon( Icons.calendar_today),
          ),
          Inputwithicon(
            textFieldHint: 'Enter your daily fee',
            textFiledName: 'Experience',
            textIcon:Icon( Icons.add_comment),
          ),
          //------------ [End] Text field section ---------


          //------------ [Begin]Delete and Save button section ---------
          Container(
            margin: EdgeInsets.only(left: 20,right: 20,top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                FlatButton(
                  color:  Color(0xFFB4A3B3B),
                  padding: EdgeInsets.only(left: 40,right: 40,top: 10,bottom: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.0),
                  ),
                  onPressed: (){ // navigate to a screen that ask again to create account or close app
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (_){
                          return ;
                        }
                    ));
                  },
                  child: Text('Delete',style: TextStyle(color: Colors.white,fontSize: 16),),
                ),
                FlatButton(
                  color:  Color(0xFFB4A3B3B),
                  padding: EdgeInsets.only(left: 40,right: 40,top: 10,bottom: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(25.0),
                  ),
                  onPressed: (){
                    showAlertDialog(context);


                  },
                  child: Text('Save',style: TextStyle(color: Colors.white,fontSize: 16),),
                ),

              ],
            ),
          )
          //------------ [End]Delete and Save button section ---------
        ],
      ),

    );
  }



//------------ [Begin] Method section ---------
  showAlertDialog(BuildContext context) {
    // Create button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.of(context).push(MaterialPageRoute(
            builder: (_){
              return HomePage();
            }
        ));
      },
    );

    // Create AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Hi Shashini"),
      content: Text("Account created successfully. Welcome to job mart !"),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
} // [End] : CrateAccount






