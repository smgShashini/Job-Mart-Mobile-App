//_______________________________________________________________________________________
// Class Description : Let users to sign up for the very first time
//                     providing phone number and password
// Actions           : Save entered data into firestore auth
//                     If user is a worker lead to create new account
// Linked Screens    : CreateNewAccount
//_______________________________________________________________________________________


import 'package:flutter/material.dart';
//import 'package:firebase_auth/firebase_auth.dart';

// [Begin] : Class SignUp
class SignUp extends StatefulWidget {
  @override
  _SignUpState createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  String _phone;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Form(
          child: Column(
            children: [
              //------------ [Begin] : Enter sign up details section ---------
              TextFormField(
                validator: ,
                onSaved: ,
                decoration:InputDecoration(
                  labelText: 'Phone number',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),

                ),
              ),
              //------------ [End] : Enter sign up details section ---------
            ],
          ),
        ),
      ),
    );
  }
}// [End] : Class SignUp
